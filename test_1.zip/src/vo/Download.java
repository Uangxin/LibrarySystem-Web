package vo;

public class Download {

}
